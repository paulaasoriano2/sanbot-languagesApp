package com.example.sanbotapp;

import okhttp3.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Objects;

import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;

import com.example.sanbotapp.robotControl.FaceRecognitionControl;
import com.qihancloud.opensdk.base.TopBaseActivity;
import com.qihancloud.opensdk.beans.FuncConstant;
import com.qihancloud.opensdk.function.beans.EmotionsType;
import com.qihancloud.opensdk.function.beans.LED;
import com.qihancloud.opensdk.function.beans.SpeakOption;
import com.qihancloud.opensdk.function.beans.handmotion.AbsoluteAngleHandMotion;
import com.qihancloud.opensdk.function.beans.headmotion.AbsoluteAngleHeadMotion;
import com.qihancloud.opensdk.function.unit.HandMotionManager;
import com.qihancloud.opensdk.function.unit.HardWareManager;
import com.qihancloud.opensdk.function.unit.HeadMotionManager;
import com.qihancloud.opensdk.function.unit.MediaManager;
import com.qihancloud.opensdk.function.unit.SpeechManager;
import com.qihancloud.opensdk.function.unit.SystemManager;
import com.qihancloud.opensdk.function.unit.WheelMotionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DetalleColorActivity extends TopBaseActivity {


    public Boolean reconocimientoFacial = false;
    private Button btnAbrirCamara;
    private Button btnComprobarColor;
    private FaceRecognitionControl faceRecognitionControl;
    private SpeechManager speechManager;
    private MediaManager mediaManager;
    private SystemManager systemManager;
    private HandMotionManager handMotionManager;
    private WheelMotionManager wheelMotionManager;
    private HeadMotionManager headMotionManager;
    private HardWareManager hardwareManager;
    private String color;
    private String color_dominant;
    private double percent;
    private JSONArray allColors;
    private String imageUriString;

    private TextView colorRespuesta;
    private Boolean isFirst;
    private Boolean notFound;
    private ImageButton btnBack;
    private Handler handler = new Handler();


    @Override
    protected void onMainServiceConnected() {

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onCreate(savedInstanceState);
        onMainServiceConnected();

        setContentView(R.layout.activity_detalle_color);

        color = getIntent().getStringExtra("color");
        isFirst = getIntent().getBooleanExtra("isFirst", true);
        imageUriString = getIntent().getStringExtra("screenshot_uri");
        notFound =getIntent().getBooleanExtra("notFound", false);
        Log.d("Color elegido", capitalizeCadena(color));
        TextView nombreColorEnPantalla = findViewById(R.id.nombreColor);
        nombreColorEnPantalla.setText(capitalizeCadena(color));

        speechManager = (SpeechManager) getUnitManager(FuncConstant.SPEECH_MANAGER);
        mediaManager = (MediaManager) getUnitManager(FuncConstant.MEDIA_MANAGER);
        systemManager = (SystemManager) getUnitManager(FuncConstant.SYSTEM_MANAGER);
        handMotionManager = (HandMotionManager) getUnitManager(FuncConstant.HANDMOTION_MANAGER);
        wheelMotionManager = (WheelMotionManager) getUnitManager(FuncConstant.WHEELMOTION_MANAGER);
        headMotionManager = (HeadMotionManager) getUnitManager(FuncConstant.HEADMOTION_MANAGER);
        hardwareManager = (HardWareManager) getUnitManager(FuncConstant.HARDWARE_MANAGER);


        faceRecognitionControl = new FaceRecognitionControl(speechManager, mediaManager);

        btnAbrirCamara = findViewById(R.id.abrirCamara);
        btnComprobarColor = findViewById(R.id.notfound);
        btnBack = findViewById(R.id.btnBack);


        faceRecognitionControl.stopFaceRecognition();

        setonClicks();




    }

    private String capitalizeCadena(String c){
        Log.d("capitalize", "tratando de capitalizar " + c);
        if (c.length() > 0 || c!=null || !c.isEmpty()) return c.substring(0,1).toUpperCase() + c.substring(1);
        else return "";
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    public void setAllButtonsClickable(boolean clickable) {
        btnAbrirCamara.setClickable(clickable);
        btnComprobarColor.setClickable(clickable);
        btnBack.setClickable(clickable);
    }

    public void setonClicks() {

        SpeakOption speakOption = new SpeakOption();
        speakOption.setSpeed(50);
        speakOption.setIntonation(50);

        setAllButtonsClickable(true);



        btnAbrirCamara.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // Se abre la cámara
                Intent intent = new Intent();
                intent.setComponent(new ComponentName("com.example.languages", "com.example.sanbotapp.robotControl.MediaControlActivity"));
                intent.putExtra("nombre_actividad", "DetalleColorActivity");
                intent.putExtra("color", color);
                intent.putExtra("isFirst",false);
                startActivityForResult(intent, 100);

                //startActivity(intent);

            }

        });

        btnBack.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnComprobarColor.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {



                if (imageUriString != null) {
                    Uri imageUri = Uri.parse(imageUriString);
                    Log.d("Captura recibida", imageUriString);


                    File file = uriToFile(imageUri);
                    sendImageToServer(file);
                }
                else{
                    Log.d("Captura recibida", "Captura recibida pero es nula");
                    String frase = "I can't see the image. Please capture it again!";
                    speechManager.startSpeak(frase, speakOption);


                }
            }

        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK) {

            String imageUriString = data.getStringExtra("screenshot_uri");
            Log.d("imageUriString", imageUriString);


            if (imageUriString != null) {
                Uri imageUri = Uri.parse(imageUriString);

                File file = uriToFile(imageUri);
                sendImageToServer(file);
            }
        }
    }

    private File uriToFile(Uri uri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            File file = new File(getCacheDir(), "temp_image.jpg");
            OutputStream outputStream = new FileOutputStream(file);

            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            outputStream.close();
            inputStream.close();

            return file;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void sendImageToServer(File imageFile) {

        new Thread(() -> {

            try {
                OkHttpClient client = new OkHttpClient.Builder()
                        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                        .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                        .build();

                RequestBody fileBody = RequestBody.create(
                        imageFile,
                        MediaType.parse("image/jpeg")
                );

                MultipartBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("image", imageFile.getName(), fileBody)
                        .build();

                Request request = new Request.Builder()
                        .url("https://opencv-pruebas.onrender.com/detect-color")
                        .post(requestBody)
                        .build();

                Response response = client.newCall(request).execute();

                if (response.isSuccessful()) {

                    String json = response.body().string();

                    JSONObject obj = new JSONObject(json);

                    color_dominant = obj.getString("dominant_color");
                    percent = obj.getDouble("percentage");
                    allColors = obj.getJSONArray("all_colors");

                    for (int i = 0; i < allColors.length(); i++) {
                        JSONArray colorItem = allColors.getJSONArray(i);

                        String name = colorItem.getString(0);
                        double percentage = colorItem.getDouble(1);

                        Log.d("COLOR LIST", name + " -> " + percentage + "%");
                    }

                    Log.d("Color dominante", color_dominant);
                    Log.d("Porcentaje", String.valueOf(percent));

                    runOnUiThread(() -> {

                        SpeakOption speakOption = new SpeakOption();
                        speakOption.setSpeed(50);
                        speakOption.setIntonation(50);

                        if (true) { //esColorCorrecto()
                            encenderFeedbackCorrecto();
                            speechManager.startSpeak(
                                    "Good job! The color was " + color,
                                    speakOption
                            );

                            animarBrazos(true);

                            ColoresDbAdapter adapter = new ColoresDbAdapter(this);
                            adapter.open();

                            adapter.updateAcierto(color, true); // ejemplo

                            adapter.close();

                            AlertDialog.Builder builder = new AlertDialog.Builder(this);
                            LayoutInflater inflater = getLayoutInflater();

                            View dialogView = inflater.inflate(R.layout.dialog_feedbackcolores, null);
                            builder.setView(dialogView);

                            AlertDialog dialog = builder.create();
                            dialog.setCancelable(false);
                            colorRespuesta = dialogView.findViewById(R.id.colorRespuesta);

                            // MODIFICAR TEXTO Y COLOR DEPENDIENDO DEL COLOR QUE SEA
                            colorRespuesta.setText(color.toUpperCase());

                            switch (color.toLowerCase()) {
                                case "red":
                                    colorRespuesta.setTextColor(Color.RED);
                                    break;

                                case "green":
                                    colorRespuesta.setTextColor(Color.GREEN);
                                    break;

                                case "blue":
                                    colorRespuesta.setTextColor(Color.BLUE);
                                    break;

                                case "purple":
                                    colorRespuesta.setTextColor(Color.MAGENTA);
                                    break;

                                case "pink":
                                    colorRespuesta.setTextColor(Color.rgb(255, 105, 180));
                                    break;

                                case "white":
                                    colorRespuesta.setTextColor(Color.WHITE);
                                    colorRespuesta.setShadowLayer(4f, 2f, 2f, Color.BLACK);
                                    break;

                                case "black":
                                    colorRespuesta.setTextColor(Color.BLACK);
                                    break;

                                case "grey":
                                    colorRespuesta.setTextColor(Color.GRAY);
                                    break;

                                default:
                                    colorRespuesta.setTextColor(Color.BLACK);
                                    break;
                            }


                            dialog.show();
                            Button btnAcceptar = dialogView.findViewById(R.id.btnAccept);
                            Button btnCancelar = dialogView.findViewById(R.id.btnCancel);

                            btnAcceptar.setOnClickListener(v -> {
                                dialog.dismiss();
                                animarBrazos(false);

                                // apagar luces
                                apagarFeedback();
                                hardwareManager.setLED(new LED(LED.PART_ALL, LED.MODE_CLOSE));
                                //finish();
                                Intent intent = new Intent(DetalleColorActivity.this, ColoresActivity.class);
                                startActivity(intent);
                                finish();
                            });

                            btnCancelar.setOnClickListener(v -> {
                                animarBrazos(false);
                                hardwareManager.setLED(new LED(LED.PART_ALL, LED.MODE_CLOSE));
                                //headMotionManager.doAbsoluteAngleMotion(new AbsoluteAngleHeadMotion(AbsoluteAngleHeadMotion.ACTION_VERTICAL,30));
                                dialog.dismiss();
                                finJuego();
                                finish();
                            });

                        } else {
                            speechManager.startSpeak(
                                    "Try again, I detected " + color_dominant,
                                    speakOption
                            );
                        }
                    });
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        }).start();
    }

    public boolean esColorCorrecto(){
        return Objects.equals(color, color_dominant);
    }

    private void animarBrazos(Boolean subir) {

        if(subir){

            // bajar izquierdo
            handler.postDelayed(() -> {
                AbsoluteAngleHandMotion leftDown =
                        new AbsoluteAngleHandMotion(AbsoluteAngleHandMotion.PART_LEFT, 30, 0);
                handMotionManager.doAbsoluteAngleMotion(leftDown);
            }, 6600);

            // derecho arriba
            handler.post(() -> {
                AbsoluteAngleHandMotion rightUp =
                        new AbsoluteAngleHandMotion(AbsoluteAngleHandMotion.PART_RIGHT, 30, 180);
                handMotionManager.doAbsoluteAngleMotion(rightUp);
            });

            // esperar y bajar derecho
            handler.postDelayed(() -> {
                AbsoluteAngleHandMotion rightDown =
                        new AbsoluteAngleHandMotion(AbsoluteAngleHandMotion.PART_RIGHT, 30, 0);
                handMotionManager.doAbsoluteAngleMotion(rightDown);
            }, 4200);



        }
        else{
            AbsoluteAngleHandMotion absoluteAngleHandMotion =
                    new AbsoluteAngleHandMotion(AbsoluteAngleHandMotion.PART_BOTH,20,180);
            handMotionManager.doAbsoluteAngleMotion(absoluteAngleHandMotion);
        }


    }

    public void encenderFeedbackCorrecto(){
        systemManager.showEmotion(EmotionsType.SURPRISE);


        if(Objects.equals(color, "red")){
            hardwareManager.setLED(new LED(LED.PART_ALL, LED.MODE_RED));
        }
        else if(Objects.equals(color, "blue")){
            hardwareManager.setLED(new LED(LED.PART_ALL, LED.MODE_BLUE));

        }
        else if(Objects.equals(color, "green")){
            hardwareManager.setLED(new LED(LED.PART_ALL, LED.MODE_GREEN));

        }
        else if(Objects.equals(color, "purple")){
            hardwareManager.setLED(new LED(LED.PART_ALL, LED.MODE_PURPLE));

        }
        else if(Objects.equals(color, "black")){

        }
        else if(Objects.equals(color, "pink")){
            hardwareManager.setLED(new LED(LED.PART_ALL, LED.MODE_PINK));
        }
        else if(Objects.equals(color, "grey")){

        }
        else if(Objects.equals(color, "white")){
            hardwareManager.setLED(new LED(LED.PART_ALL, LED.MODE_WHITE));

        }
    }

    public void apagarFeedback(){

    }

    @Override
    public void onResume() {
        SpeakOption speakOption = new SpeakOption();
        speakOption.setSpeed(50);
        speakOption.setIntonation(50);
        super.onResume();
        if(isFirst){
            btnComprobarColor.setVisibility(View.GONE);

        }
        // Inicializamos el sistema
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


                if(isFirst){

                    btnComprobarColor.setVisibility(View.GONE);

                    AbsoluteAngleHeadMotion absoluteAngleHeadMotion =
                            new AbsoluteAngleHeadMotion(AbsoluteAngleHeadMotion.ACTION_HORIZONTAL,7);
                    headMotionManager.doAbsoluteAngleMotion(absoluteAngleHeadMotion);

                    String frase2 = "Let's look for an object of that colour!";
                    speechManager.startSpeak(frase2, speakOption);

                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    AbsoluteAngleHeadMotion absoluteAngleHeadMotion2 =
                            new AbsoluteAngleHeadMotion(AbsoluteAngleHeadMotion.ACTION_HORIZONTAL,-7);
                    headMotionManager.doAbsoluteAngleMotion(absoluteAngleHeadMotion2);


                    String frase3 = "When you find it, tap";
                    speechManager.startSpeak(frase3, speakOption);

                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    String frase = "Let's do it! The color you have chosen is";
                    speakOption.setLanguageType(SpeakOption.LAG_ENGLISH_US);
                    speechManager.startSpeak(frase, speakOption);
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    speechManager.startSpeak(color, speakOption);


                    AbsoluteAngleHeadMotion absoluteAngleHeadMotion3 =
                            new AbsoluteAngleHeadMotion(AbsoluteAngleHeadMotion.ACTION_HORIZONTAL,90);
                    headMotionManager.doAbsoluteAngleMotion(absoluteAngleHeadMotion3);
                }

                else if(notFound){
                    String frase = "Don't worry we can try with other colour";
                    speakOption.setLanguageType(SpeakOption.LAG_ENGLISH_US);
                    speechManager.startSpeak(frase, speakOption);
                    finish();
                }
                else{

                    btnComprobarColor.setVisibility(View.VISIBLE);

                    String frase = "I have received your photo. Tap on check colour";
                    speakOption.setLanguageType(SpeakOption.LAG_ENGLISH_US);
                    speechManager.startSpeak(frase, speakOption);
                }



                //speechManager.startSpeak(color, speakOption);

            }
        }, 200);

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();



        return super.onOptionsItemSelected(item);
    }

    private void finJuego() {

        SpeakOption speakOption = new SpeakOption();
        speakOption.setSpeed(40);
        speakOption.setIntonation(50);

        speechManager.startSpeak("That was amazing! Let's continue playing later!", speakOption);

        systemManager.showEmotion(EmotionsType.SMILE);
        hardwareManager.setLED(new LED(LED.PART_ALL, LED.MODE_BLUE));

        AbsoluteAngleHandMotion motion =
                new AbsoluteAngleHandMotion(AbsoluteAngleHandMotion.PART_BOTH,20,0);
        handMotionManager.doAbsoluteAngleMotion(motion);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        motion =
                new AbsoluteAngleHandMotion(AbsoluteAngleHandMotion.PART_BOTH,20,180);
        handMotionManager.doAbsoluteAngleMotion(motion);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        hardwareManager.setLED(new LED(LED.PART_ALL, LED.MODE_CLOSE));

        Intent intent = new Intent(DetalleColorActivity.this, MainActivity.class);
        startActivity(intent);


    }


}
